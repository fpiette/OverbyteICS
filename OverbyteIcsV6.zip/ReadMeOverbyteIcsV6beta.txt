ICS Version 6 beta 29/12/2005
=============================

What's new ?
------------

This version share a single window handle among a lot of ICS components.
The component itself has the same interface as previous version. So your
application code doesn't need to be updated. If you derived your own
component from ICS components, you have to change the way you handle
windows messages.

Known issues
------------
Currently only TWSocket, TWSocketServer, THttpCli, THttpServer, TFtpClient
and TFtpServer have been created.
The demos have not really been updated. They are the code which existed
around mid-2004. Not a big deal.
Component icons have not been built.
Only Delphi 7 and Delphi 2006.win32 have been tested.

--
francois.piette@overbyte.be
http://www.overbyte.be
