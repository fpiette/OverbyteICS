import java.applet.*;
import java.awt.*;

public class HelloWorld extends Applet {
    public void paint( Graphics g ) {
        g.drawString("Hello World",50,25);
}   }

